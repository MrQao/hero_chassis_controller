#include <ros/ros.h>
#include <std_msgs/Float64.h>
#include <std_msgs/Int64.h>
#include "simple_chassis_controller/simple_chassis_controller.h"
#include <pluginlib/class_list_macros.hpp>
#include <angles/angles.h>
#include <geometry_msgs/Twist.h>

namespace simple_chassis_controller {

SimpleChassisController::SimpleChassisController()
  : loop_count_(0)
{}

SimpleChassisController::~SimpleChassisController()
{
  sub_command_.shutdown();
}

bool SimpleChassisController::init(hardware_interface::EffortJointInterface *effort_joint_interface,
				    ros::NodeHandle &root_nh, ros::NodeHandle &controller_nh) {
   // Get joint name from parameter server
  front_left_joint_ = effort_joint_interface->getHandle("front_left_wheel_joint");
  front_right_joint_ = effort_joint_interface->getHandle("front_right_wheel_joint");
  back_left_joint_ = effort_joint_interface->getHandle("back_left_wheel_joint");
  back_right_joint_ = effort_joint_interface->getHandle("back_right_wheel_joint");

  // Load PID Controller using gains set on parameter server
  pid1_controller.init(ros::NodeHandle(controller_nh, "pid1"));
  pid2_controller.init(ros::NodeHandle(controller_nh, "pid2"));
  pid3_controller.init(ros::NodeHandle(controller_nh, "pid3"));
  pid4_controller.init(ros::NodeHandle(controller_nh, "pid4"));
  // Start realtime state publisher
  controller_state_publisher_.reset(
    new realtime_tools::RealtimePublisher<control_msgs::JointControllerState>(controller_nh, "state", 1));

  // Start command subscriber
  sub_command_ = root_nh.subscribe<geometry_msgs::Twist>("vel_cmd", 1, &SimpleChassisController::setCommandCB, this);

  return true;
}

void SimpleChassisController::update(const ros::Time& time, const ros::Duration& period)
{
  double r=0.7625;
  //get the v of each wheel
  vel_act[0] = front_left_joint_.getVelocity();
  vel_act[1] = front_right_joint_.getVelocity();
  vel_act[2] = back_left_joint_.getVelocity();
  vel_act[3] = back_right_joint_.getVelocity();

  //get the v of the car
  vx=(vel_act[0]+vel_act[1]+vel_act[2]+vel_act[3])*r/4;
  vy=(vel_act[0]-vel_act[1]-vel_act[2]+vel_act[3])*r/4;
  vc=(-vel_act[0]+vel_act[1]-vel_act[2]+vel_act[3])*r/2;
// a 2vx+2vy=0+3  
// b 2vx-2vy=1+2 a-c+f=0+0  2vx+2vy-(2vx+vc)+2vy-vc=4vy-2vc     2vy-vc
// c 2vx+vc=1+3  b-e+c=1+1  2vx-2vy-(2vy+vc)+2vx+vc=4vx-4vy     2vx-2vy
// d 2vx-vc=1+2  b-c+d=2+2  2vx-2vy-(2vx+vc)+2vx-vc=2vx-2vy-2vc vx-vy-vc
// e 2vy+vc=2+3  c-b+e=3+3  2vx+vc-(2vx-2vy)+2vy+vc=4vy+2vc     2vy+vc
// f 2vy-vc=0+1
  ROS_INFO("the speed:%lf",vel_act[0]);
  //get the command v of each wheel
  vel_cmd[0] = (vx_cmd + vy_cmd + vc_cmd / 2) / r;
  vel_cmd[1] = (vx_cmd - vy_cmd - vc_cmd / 2) / r;
  vel_cmd[2] = (vx_cmd + vy_cmd - vc_cmd / 2) / r;
  vel_cmd[3] = (vx_cmd - vy_cmd + vc_cmd / 2) / r;
  //get error of each wheel
  for(int i=0;i<4;i++)error[i]=vel_cmd[i]-vel_act[i];
  //culculate the position of car
  x+=(vx*cos(c)+vy*sin(c))*period.toSec();
  y+=(vx*sin(c)+vy*cos(c))*period.toSec();
  c+=vc*period.toSec();
  //give the command to each wheel
  ROS_INFO("the vx_cmd is :%lf",vx_cmd);
  if(vx_cmd!=0||vy_cmd!=0||vc_cmd!=0){
  ROS_INFO("commmand=%lf",pid2_controller.computeCommand(error[1],period));
  front_right_joint_.setCommand(pid1_controller.computeCommand(error[0], period));
  front_left_joint_.setCommand(pid2_controller.computeCommand(error[1], period));
  back_left_joint_.setCommand(pid3_controller.computeCommand(error[2], period));
  back_right_joint_.setCommand(pid4_controller.computeCommand(error[3], period));
  }
  // publish state
  if (loop_count_ % 10 == 0)
  {
    if(controller_state_publisher_ && controller_state_publisher_->trylock())
    {
      controller_state_publisher_->msg_.header.stamp = time;
      controller_state_publisher_->msg_.set_point = vel_cmd[0];
      controller_state_publisher_->msg_.process_value = vel_act[0];
      controller_state_publisher_->msg_.process_value_dot = error[0];
      controller_state_publisher_->msg_.error = error[0];
      controller_state_publisher_->msg_.time_step = period.toSec();
      controller_state_publisher_->msg_.command = pid1_controller.computeCommand(error[0], period);

      double dummy;
      bool antiwindup;
      pid1_controller.getGains(controller_state_publisher_->msg_.p,
        controller_state_publisher_->msg_.i,
        controller_state_publisher_->msg_.d,
        controller_state_publisher_->msg_.i_clamp,
        dummy,
        antiwindup);
      controller_state_publisher_->msg_.antiwindup = static_cast<char>(antiwindup);
      controller_state_publisher_->unlockAndPublish();
    }
  }
  loop_count_++;
}

void SimpleChassisController::setCommandCB(const geometry_msgs::TwistConstPtr& msg)
{
  vx_cmd=msg->linear.x;
  vy_cmd=msg->linear.y;
  vc_cmd=msg->angular.z;
}

PLUGINLIB_EXPORT_CLASS( simple_chassis_controller::SimpleChassisController, controller_interface::ControllerBase)
}// namespace
