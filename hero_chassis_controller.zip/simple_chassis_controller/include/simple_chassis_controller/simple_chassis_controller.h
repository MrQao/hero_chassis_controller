#ifndef SIMPLE_CHASSIS_CONTROLLER_SIMPLE_CHASSIS_CONTROLLER_H
#define SIMPLE_CHASSIS_CONTROLLER_SIMPLE_CHASSIS_CONTROLLER_H

#include <control_msgs/JointControllerState.h>
#include <control_msgs/JointControllerState.h>
#include <control_toolbox/pid.h>
#include <controller_interface/controller.h>
#include <hardware_interface/joint_command_interface.h>
#include <memory>
#include <realtime_tools/realtime_buffer.h>
#include <realtime_tools/realtime_publisher.h>
#include <ros/node_handle.h>
#include <std_msgs/Float64.h>
#include <urdf/model.h>
#include <geometry_msgs/Twist.h>

namespace simple_chassis_controller{

class SimpleChassisController: public controller_interface::Controller<hardware_interface::EffortJointInterface>
{
public:
  SimpleChassisController();
  ~SimpleChassisController();
  /** \brief The init function is called to initialize the controller from a
   * non-realtime thread with a pointer to the hardware interface, itself,
   * instead of a pointer to a RobotHW.
   *
   * \param robot The specific hardware interface used by this controller.
   *
   * \param n A NodeHandle in the namespace from which the controller
   * should read its configuration, and where it should set up its ROS
   * interface.
   *
   * \returns True if initialization was successful and the controller
   * is ready to be started.
   */
  bool init(hardware_interface::EffortJointInterface *effort_joint_interface,
            ros::NodeHandle &root_nh, ros::NodeHandle &controller_nh) override;

  void update(const ros::Time& time, const ros::Duration& period);

  control_toolbox::Pid pid1_controller, pid2_controller, pid3_controller, pid4_controller;
  
  hardware_interface::JointHandle front_left_joint_, front_right_joint_, back_left_joint_, back_right_joint_;
  
private:
  int loop_count_;
  double vel_cmd[4]{0.0,0.0,0.0,0.0};
  double vel_act[4];
  double x{0.0},y{0.0},c{0.0};
  double vx_cmd{0.0},vy_cmd{0.0},vc_cmd{0.0};
  double vx{0.0},vy{0.0},vc{0.0};
  double error[4]{0.0,0.0,0.0,0.0};
  
  std::unique_ptr<
    realtime_tools::RealtimePublisher<
      control_msgs::JointControllerState> > controller_state_publisher_ ;

  ros::Subscriber sub_command_;

  /**
   * \brief Callback from /command subscriber for setpoint
   */
  void setCommandCB(const geometry_msgs::TwistConstPtr& msg);

};
} // namespace
#endif //SIMPLE_CHASSIS_CONTROLLER_SIMPLE_CHASSIS_CONTROLLER_H
